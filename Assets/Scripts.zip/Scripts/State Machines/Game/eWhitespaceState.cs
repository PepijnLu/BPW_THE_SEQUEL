using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class eWhitespaceState : GameBaseState
{
    public override void EnterState(GameStateManager gameSM)
    {

    }
    public override void UpdateState(GameStateManager gameSM)
    {

    }

    public override void FixedUpdateState(GameStateManager gameSM)
    {

    }
}
