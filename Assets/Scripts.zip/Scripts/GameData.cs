using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class GameData 
{
    public static int dungeonsCompleted;
    public static float musicVolume = 0.2f;
    public static float sfxVolume = 0.2f;
}
