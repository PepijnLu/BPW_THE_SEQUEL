using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class BattleManager : MonoBehaviour
{
    public static BattleManager instance;
    public Transform playerCardSlot, enemyCardSlot;
    public bool battle;
    public List<GameObject> battleOpponents;
    public Image playerSword, enemySword;
    GameObject[] cards;

    void Awake()
    {
        instance = this;
        GameObject[] deactivates = GameObject.FindGameObjectsWithTag("Deactivate");
        foreach (GameObject deactivate in deactivates)
        {
            deactivate.SetActive(false);
        }
        battleOpponents = new List<GameObject>(){};
    }

    void Start()
    {
        
    }

    public void Battle(GameObject player, GameObject enemy, bool resetAudio, bool playerIniate)
    {
        if (resetAudio)
        {
            StartCoroutine(AudioManager.instance.AudioFadeIn(AudioManager.instance.audioSources["battleTheme"], 0.2f));
            AudioManager.instance.PlaySound(AudioManager.instance.audioSources["battleTheme"]);
            StartCoroutine(AudioManager.instance.AudioFadeOut(AudioManager.instance.audioSources["gameTheme"], 0.5f));
        }

        enemy.GetComponent<Stats>().inBattle = true;
        GameManager.instance.stopped = true;

        if (enemy.GetComponent<Stats>().inList == false)
        {
            battleOpponents.Add(enemy);
            enemy.GetComponent<Stats>().inList = true;
        }
        if ( (battleOpponents.Count > 0) && (battle == false) )
        {
            battle = true;

            foreach(GameObject card in ProcGen.instance.cards)
            {
                card.SetActive(false);
            }

            Stats playerStats = player.GetComponent<Stats>();
            Stats enemyStats = battleOpponents[0].GetComponent<Stats>();

            playerStats.card.SetActive(true);
            enemyStats.card.SetActive(true);

            ///UpdateUI(playerStats, enemyStats, playerDamage, enemyDamage);
            StartCoroutine(DisableCards(playerStats, enemyStats, resetAudio, playerIniate));
        }
    }

    IEnumerator DisableCards(Stats playerStats, Stats enemyStats, bool resetAudio, bool playerIniate)
    {
        int playerDamage = enemyStats.damage;
        int enemyDamage = playerStats.damage;

        yield return new WaitForSeconds(1);

        if (enemyStats.firstStrike)
        {
            enemySword.transform.position = enemyCardSlot.transform.position;
            enemySword.gameObject.SetActive(true);
            float elapsedTime = 0f;
            Vector2 startPos = enemySword.transform.position;
            while (elapsedTime < 1f)
            {
                float t = elapsedTime / 1f;
                enemySword.transform.position = Vector2.Lerp(startPos, playerCardSlot.transform.position, t);
                elapsedTime += Time.deltaTime;
                yield return null;
            }
            enemySword.gameObject.SetActive(false);
            playerStats.health -= playerDamage;
            playerStats.hpText.text = playerStats.health.ToString();
            //yield return new WaitForSeconds(2);
            if (playerStats.health <= 0)
            {
                playerStats.health = 0;
                playerStats.hpText.text = playerStats.health.ToString();
                StartCoroutine(AudioManager.instance.AudioFadeOut(AudioManager.instance.audioSources["battleTheme"], 1.5f));
                yield return new WaitForSeconds(2);
                SceneManager.LoadScene("GameOver");
                playerStats.card.SetActive(false);
                playerStats.gameObject.SetActive(false);
            }
            else
            {
                playerSword.transform.position = playerCardSlot.transform.position;
                playerSword.gameObject.SetActive(true);
                float elapsedTime2 = 0f;
                Vector2 startPos2 = playerSword.transform.position;
                while (elapsedTime2 < 1f)
                {
                    float t = elapsedTime2 / 1f;
                    playerSword.transform.position = Vector2.Lerp(startPos2, enemyCardSlot.transform.position, t);
                    elapsedTime2 += Time.deltaTime;
                    yield return null;
                }
                playerSword.gameObject.SetActive(false);
                enemyStats.health -= enemyDamage;
                enemyStats.hpText.text = enemyStats.health.ToString();
                if (enemyStats.health <= 0)
                {
                    enemyStats.health = 0;
                    enemyStats.hpText.text = enemyStats.health.ToString();
                    StartCoroutine(AudioManager.instance.AudioFadeOut(AudioManager.instance.audioSources["battleTheme"], 1f));
                    yield return new WaitForSeconds(1);
                    if ( (enemyStats.moves < enemyStats.maxMoves))
                    {
                        TurnManager.instance.CheckActions(enemyStats.gameObject);
                    }
                    //DestroyArrows(enemyStats.gameObject);
                    battleOpponents.Remove(enemyStats.gameObject);
                    enemyStats.card.SetActive(false);
                    enemyStats.gameObject.SetActive(false);
                    playerStats.card.SetActive(false);
                    if (playerStats.moves >= playerStats.maxMoves)
                    {
                        TurnManager.instance.CheckActions(playerStats.gameObject);
                    }
                }
            }

        }
        else
        {
            
            playerSword.transform.position = playerCardSlot.transform.position;
            playerSword.gameObject.SetActive(true);
            float elapsedTime = 0f;
            Vector2 startPos = playerSword.transform.position;
            while (elapsedTime < 1f)
            {
                float t = elapsedTime / 1f;
                playerSword.transform.position = Vector2.Lerp(startPos, enemyCardSlot.transform.position, t);
                elapsedTime += Time.deltaTime;
                yield return null;
            }
            playerSword.gameObject.SetActive(false);
            enemyStats.health -= enemyDamage;
            enemyStats.hpText.text = enemyStats.health.ToString();
            if (enemyStats.health <= 0)
            {
                enemyStats.health = 0;
                enemyStats.hpText.text = enemyStats.health.ToString();
                StartCoroutine(AudioManager.instance.AudioFadeOut(AudioManager.instance.audioSources["battleTheme"], 1f));
                yield return new WaitForSeconds(1);
                if ( (enemyStats.moves < enemyStats.maxMoves))
                {
                    TurnManager.instance.CheckActions(enemyStats.gameObject);
                }
                battleOpponents.Remove(enemyStats.gameObject);
                enemyStats.card.SetActive(false);
                enemyStats.gameObject.SetActive(false);
                playerStats.card.SetActive(false);
                if (playerStats.moves >= playerStats.maxMoves)
                {
                    TurnManager.instance.CheckActions(playerStats.gameObject);
                }
            }
            else
            {
                enemySword.transform.position = enemyCardSlot.transform.position;
                enemySword.gameObject.SetActive(true);
                float elapsedTime2 = 0f;
                Vector2 startPos2 = enemySword.transform.position;
                while (elapsedTime2 < 1f)
                {
                    float t = elapsedTime2 / 1f;
                    enemySword.transform.position = Vector2.Lerp(startPos2, playerCardSlot.transform.position, t);
                    elapsedTime2 += Time.deltaTime;
                    yield return null;
                }
                enemySword.gameObject.SetActive(false);
                playerStats.health -= playerDamage;
                playerStats.hpText.text = playerStats.health.ToString();
                if (playerStats.health <= 0)
                {   
                    playerStats.health = 0;
                    playerStats.hpText.text = playerStats.health.ToString();
                    StartCoroutine(AudioManager.instance.AudioFadeOut(AudioManager.instance.audioSources["battleTheme"], 1.5f));
                    yield return new WaitForSeconds(2);
                    SceneManager.LoadScene("GameOver");
                    playerStats.card.SetActive(false);
                    playerStats.gameObject.SetActive(false);
                }
            }
        }
        battle = false;
        if ( (playerStats.health > 0) && (enemyStats.health > 0))
        {
            Battle(playerStats.gameObject, enemyStats.gameObject, false);
        }
        else
        {
            GameManager.instance.stopped = false;
            yield return new WaitForSeconds(0.2f);
            if(battleOpponents.Count > 0)
            {
                Battle(playerStats.gameObject, battleOpponents[0], false);
            }
            else
            {
                enemyStats.inBattle = false;
                enemyStats.inList = false;
                StartCoroutine(AudioManager.instance.AudioFadeOut(AudioManager.instance.audioSources["battleTheme"], 0.5f));
                StartCoroutine(AudioManager.instance.AudioFadeIn(AudioManager.instance.audioSources["gameTheme"], 0.5f));
            }
        }

        // if ( (TurnManager.instance.isPlayerTurn) && (playerStats.moves >= playerStats.maxMoves))
        // {
        //     PlayerController playerController = playerStats.gameObject.GetComponent<PlayerController>();
        //     Movement.instance.EndTurn(playerStats.gameObject, playerController.up, playerController.down, playerController.left, playerController.right);
        // }
        if (TurnManager.instance.isPlayerTurn && !playerStats.turnDone)
        {
            // if (playerStats.moves < playerStats.maxMoves)
            // {
            //     playerStats.gameObject.GetComponent<PlayerController>().CheckForPossibleMovement();
            // }
            StartCoroutine(Movement.instance.EndMove(playerStats));
        }
        if (!TurnManager.instance.isPlayerTurn && !enemyStats.turnDone)
        {
            StartCoroutine(Movement.instance.EndMove(enemyStats));
        }
    }
}
